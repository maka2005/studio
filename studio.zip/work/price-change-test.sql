begin;
do $$
declare pid uuid; before_count int; after_count int; old_price int;
begin
 select p.id,p.price_kzt into pid,old_price from public.plans p
 where p.price_kzt>0 and exists(select 1 from public.subscriptions s where s.plan_id=p.id and s.status in ('trial','active','grace')) limit 1;
 if pid is null then raise exception 'test_fixture_missing'; end if;
 select count(*) into before_count from public.subscription_price_changes;
 update public.plans set price_kzt=old_price+1 where id=pid;
 select count(*) into after_count from public.subscription_price_changes;
 if after_count<=before_count then raise exception 'price_change_proposals_not_created'; end if;
end $$;
rollback;